class Slider{
    constructor(
        id,
        lista_elementos,
        navegador,
        estilo_navegador,
        paginador,
        estilo_paginador,
        tiempo_animacion,
        estilo_animacion,
        auto,
    ){
        this.id = id;
        this.lista_elementos = lista_elementos;
        this.navegador = navegador;
        this.estilo_navegador = estilo_navegador
        this.paginador = paginador;
        this.estilo_paginador = estilo_paginador;
        this.tiempo_animacion = tiempo_animacion;
        this.estilo_animacion = estilo_animacion;
        this.auto = auto;

        this.setUpActions();
    }

    setUpActions(){
        console.log('Setup is on the way');
        this.setSliderDimentions();
        this.setSliderNav();
        this.setSliderImages();
        this.setSliderEvents();
    }

    setSliderDimentions(){
        let sliderCanvas = document.querySelector(`#${this.id}`);
        //definir width & heigth
        console.log(sliderCanvas);
    }

    setSliderNav(){
        //document.createElement
        //appendChild
    }

    setSliderImages(){/*CHUNK*/}

    setSliderEvents(){/*CHUNK*/}

    getImprimirInfo(){
        console.log(this.lista_elementos, this.navegador, this.estilo_navegador,
                    this.paginador, this.estilo_paginador, this.tiempo_animacion,
                    this.estilo_animacion, this.auto)
    }
}

let sliderPrincipal = new Slider('slider-principal', [], true, 'square', true, 'square', 0.5, 'linear', false);
// let sliderSecundario = new Slider([], false, '', false, '', 0.5, 'linear', true);
// sliderPrincipal.getImprimirInfo();